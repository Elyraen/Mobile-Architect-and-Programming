package com.example.goaltrack;
import android.content.Context;
/** Holds the signed-in user's ID between app launches. */
public final class Session {
 private Session() {}
 public static void start(Context c,long id){c.getSharedPreferences("session",0).edit().putLong("uid",id).apply();}
 public static long id(Context c){return c.getSharedPreferences("session",0).getLong("uid",-1);}
 public static void end(Context c){c.getSharedPreferences("session",0).edit().remove("uid").apply();}
}
