package com.example.goaltrack;
import android.content.*; import android.database.*; import android.database.sqlite.*; import android.util.Base64;
import java.security.*; import java.nio.charset.StandardCharsets; import java.util.*; import javax.crypto.SecretKeyFactory; import javax.crypto.spec.PBEKeySpec;
/** All persistent data operations are kept in this SQLite helper. */
public class DatabaseHelper extends SQLiteOpenHelper {
 public DatabaseHelper(Context c){super(c,"goaltrack.db",null,1);}
 public void onCreate(SQLiteDatabase d){d.execSQL("CREATE TABLE users(id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE COLLATE NOCASE NOT NULL, hash TEXT NOT NULL, salt TEXT NOT NULL)");d.execSQL("CREATE TABLE weights(id INTEGER PRIMARY KEY AUTOINCREMENT, uid INTEGER NOT NULL, date TEXT NOT NULL, weight REAL NOT NULL, note TEXT, FOREIGN KEY(uid) REFERENCES users(id))");d.execSQL("CREATE TABLE settings(uid INTEGER PRIMARY KEY, goal REAL NOT NULL DEFAULT 175, phone TEXT DEFAULT '', alerted INTEGER NOT NULL DEFAULT 0, FOREIGN KEY(uid) REFERENCES users(id))");}
 public void onUpgrade(SQLiteDatabase d,int o,int n){/* Future schema migrations should preserve existing user data. */}
 private String salt(){byte[] b=new byte[16];new SecureRandom().nextBytes(b);return Base64.encodeToString(b,Base64.NO_WRAP);}
 private String hash(String p,String s){try{PBEKeySpec spec=new PBEKeySpec(p.toCharArray(),Base64.decode(s,Base64.NO_WRAP),120000,256);byte[] b=SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();spec.clearPassword();return Base64.encodeToString(b,Base64.NO_WRAP);}catch(Exception e){throw new IllegalStateException(e);}}
 public boolean exists(String u){try(Cursor c=getReadableDatabase().rawQuery("SELECT id FROM users WHERE username=?",new String[]{u.trim()})){return c.moveToFirst();}}
 public long create(String u,String p){String s=salt();ContentValues v=new ContentValues();v.put("username",u.trim());v.put("hash",hash(p,s));v.put("salt",s);long id=getWritableDatabase().insert("users",null,v);if(id>0){ContentValues x=new ContentValues();x.put("uid",id);x.put("goal",175);getWritableDatabase().insert("settings",null,x);}return id;}
 public long login(String u,String p){try(Cursor c=getReadableDatabase().rawQuery("SELECT id,hash,salt FROM users WHERE username=?",new String[]{u.trim()})){if(!c.moveToFirst())return -1;return MessageDigest.isEqual(c.getString(1).getBytes(StandardCharsets.UTF_8),hash(p,c.getString(2)).getBytes(StandardCharsets.UTF_8))?c.getLong(0):-1;}}
 public static class Entry {public long id;public String date,note;public double weight;Entry(long i,String d,double w,String n){id=i;date=d;weight=w;note=n==null?"":n;}}
 public List<Entry> entries(long uid){List<Entry> a=new ArrayList<>();try(Cursor c=getReadableDatabase().rawQuery("SELECT id,date,weight,note FROM weights WHERE uid=? ORDER BY date DESC,id DESC",new String[]{""+uid})){while(c.moveToNext())a.add(new Entry(c.getLong(0),c.getString(1),c.getDouble(2),c.getString(3)));}return a;}
 public long add(long uid,String date,double weight,String note){ContentValues v=new ContentValues();v.put("uid",uid);v.put("date",date);v.put("weight",weight);v.put("note",note);return getWritableDatabase().insert("weights",null,v);}
 public void update(long id,long uid,String date,double weight,String note){ContentValues v=new ContentValues();v.put("date",date);v.put("weight",weight);v.put("note",note);getWritableDatabase().update("weights",v,"id=? AND uid=?",new String[]{""+id,""+uid});}
 public void delete(long id,long uid){getWritableDatabase().delete("weights","id=? AND uid=?",new String[]{""+id,""+uid});}
 public double goal(long uid){try(Cursor c=getReadableDatabase().rawQuery("SELECT goal FROM settings WHERE uid=?",new String[]{""+uid})){return c.moveToFirst()?c.getDouble(0):175;}}
 public void goal(long uid,double g){ContentValues v=new ContentValues();v.put("goal",g);v.put("alerted",0);getWritableDatabase().update("settings",v,"uid=?",new String[]{""+uid});}
 public String phone(long uid){try(Cursor c=getReadableDatabase().rawQuery("SELECT phone FROM settings WHERE uid=?",new String[]{""+uid})){return c.moveToFirst()?c.getString(0):"";}}
 public void phone(long uid,String p){ContentValues v=new ContentValues();v.put("phone",p);getWritableDatabase().update("settings",v,"uid=?",new String[]{""+uid});}
 public boolean alerted(long uid){try(Cursor c=getReadableDatabase().rawQuery("SELECT alerted FROM settings WHERE uid=?",new String[]{""+uid})){return c.moveToFirst()&&c.getInt(0)==1;}}
 public void markAlerted(long uid){ContentValues v=new ContentValues();v.put("alerted",1);getWritableDatabase().update("settings",v,"uid=?",new String[]{""+uid});}
}
