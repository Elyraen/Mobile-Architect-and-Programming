package com.example.goaltrack;
import android.content.*;import android.os.Bundle;import android.widget.*;import androidx.appcompat.app.AppCompatActivity;
/** Allows existing users to sign in and new users to create an account. */
public class LoginActivity extends AppCompatActivity {
 DatabaseHelper db; EditText user,pass;
 protected void onCreate(Bundle b){super.onCreate(b);db=new DatabaseHelper(this);if(Session.id(this)>0){open();return;}setContentView(R.layout.activity_login);user=findViewById(R.id.usernameInput);pass=findViewById(R.id.passwordInput);findViewById(R.id.loginButton).setOnClickListener(v->login());findViewById(R.id.createAccountButton).setOnClickListener(v->create());}
 boolean valid(){if(user.getText().toString().trim().isEmpty()||pass.getText().length()<6){Toast.makeText(this,"Enter a username and password with at least 6 characters.",Toast.LENGTH_LONG).show();return false;}return true;}
 void login(){if(!valid())return;long id=db.login(user.getText().toString(),pass.getText().toString());if(id>0){Session.start(this,id);open();}else Toast.makeText(this,"Login failed. Check your details or create an account.",Toast.LENGTH_LONG).show();}
 void create(){if(!valid())return;if(db.exists(user.getText().toString())){Toast.makeText(this,"Username already exists. Log in or choose another.",Toast.LENGTH_LONG).show();return;}long id=db.create(user.getText().toString(),pass.getText().toString());if(id>0){Session.start(this,id);open();}else Toast.makeText(this,"Could not create account.",Toast.LENGTH_LONG).show();}
 void open(){startActivity(new Intent(this,DashboardActivity.class));finish();}
}
